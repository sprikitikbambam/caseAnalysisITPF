/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banking_system;

import java.util.Scanner;

/**
 *
 * @author ralph
 */
public class Banking_System {
    private double balance;
    public Banking_System(double initialBalance) {
        this.balance = initialBalance;
    }
    public void deposit(double amount) {
        try {
            if (amount <= 0) {
                throw new IllegalArgumentException("Deposit amount must be greater than 0.");
            }
            balance += amount;
            System.out.println("Deposit successful. New balance: " + balance);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Deposit transaction completed.");
        }
    }
    public void withdraw(double amount) {
        try {
            if (amount <= 0) {
                throw new IllegalArgumentException("Withdrawal amount must be greater than 0.");
            }
            if (amount > balance) {
                throw new IllegalArgumentException("Insufficient funds! Balance: " + balance);
            }
            balance -= amount;
            System.out.println("Withdrawal successful. New balance: " + balance);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Withdrawal transaction completed.");
        }
    }
    
    public static void main(String[] args) {
        Scanner poklong = new Scanner(System.in);
        System.out.print("Enter initial account balance: ");
        while (!poklong.hasNextDouble()) {
            System.out.println("Invalid input. Please enter a numeric value.");
            poklong.next();
        }
        double initialBalnace = poklong.nextDouble();
        
        Banking_System bankAccount = new Banking_System(initialBalnace);
         while (true) {
            System.out.println("\n\t\t\tChoose an option: \n\t\t1) Deposit  \n\t\t2) Withdraw  \n\t\t3) Exit");
            System.out.print("Choice: ");
            int choice = poklong.nextInt();
            
            if (choice == 3) {
                System.out.println("Exiting program.");
                break;
            }
            
            System.out.print("Enter amount: ");
            double amount = poklong.nextDouble();
            
            if (choice == 1) {
                bankAccount.deposit(amount);
            } else if (choice == 2) {
                bankAccount.withdraw(amount);
            } else {
                System.out.println("Invalid option.");
            }
        }
    }
}