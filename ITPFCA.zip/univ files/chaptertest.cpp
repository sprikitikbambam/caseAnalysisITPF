#include <iostream>
#include <cstdlib>

using namespace std;

int square(int side)
{
    int area;

    square = side * side;

    return area;
}

int rectangle(int length, int width)
{
    int area;

    rectangle = length * width;

    return area;
}

double circle(double 3.1416, double radius * radius)
{
    double area;

    circle = 3.1416 * radius * radius;

    return area;
}

double triangle(double base, height, 0.5)
{
    double area;

    triangle = base * height / 2;

    return area;
}

int main()
{
    double r, b, h, aot, aoc;
    int s, l, w, oas, oar;
    char fLetter;

    cout<<"Enter the first letter of the shape(s, c, t, r): ";
    cin>>fLetter;

    switch(letter)
    {
        case 'r'
            cout<<"Enter length: ";
            cin>>l;
            cout<<"Enter width: ";
            cin>>w;
            oar = Rectangle(l, w)

            cout<<"The area of rectangle is "<<oar<<endl<<endl;
            break;
        case 's'
            cout<<"Enter side: ";
            cin>>s
            aos = Square(s)

            cout<<"The area of square is "<<oas<<endl<<endl;
            break;
        case 'c'
            cout<<"Enter radius: ";
            cin>>r;
            oac = Circle(c)

            cout<<"The area of circle is "<<oac<<endl<<endl;
            break;

        case 't'
            cout<<"Enter the base: ";
            cin>>b;
            cout<<"Enter the height: ";
            cin>>h;
            aot = Triangle(b, h)

            cout<<"The area of triangle is "<<aot<<endl<<endl;
            break;
        default;
            cout<<"Error! Tanga ka ba?"<<endl<<endl;
    }

    return EXIT_SUCCESS;
}